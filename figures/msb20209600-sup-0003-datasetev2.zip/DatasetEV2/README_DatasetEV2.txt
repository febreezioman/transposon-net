Custom consensus repeat library used in conjunction with RepeatMasker to identify transposons in all the used genomes. The headers contain the sequence origin, superfamily and subfamily classification of each sequence in the format [species identifier]#[superfamily]/[subfamily].
 
